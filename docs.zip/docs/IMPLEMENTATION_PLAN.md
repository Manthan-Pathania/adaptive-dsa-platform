# Phased Implementation Plan & Dependency Graph — Adaptive DSA Interview Preparation Platform

## 1. Overview & Execution Strategy

This implementation plan breaks the project into **six sequential, dependency-aware phases**.
Each phase delivers a **verifiable vertical slice** with testable acceptance criteria. No phase begins until the previous phase's automated tests and quality gates pass.

```mermaid
graph TD
    P0["Phase 0: Specification & Architecture<br/>(Current Planning Task)"]
    P1["Phase 1: Engineering Foundation<br/>(Go, pgxpool, Goose, sqlc, Docker, CI)"]
    P2["Phase 2: Identity & Security<br/>(Argon2id, Sessions, Cookies, RBAC, Audit)"]
    P3["Phase 3: Core Preparation Engine<br/>(Catalog, Roadmaps, Progress, SM-2 Engine, Importer CLI)"]
    P4["Phase 4: User Experience & AI Credits<br/>(Next.js UI, Daily Dashboard, Gemini, Credit Ledger)"]
    P5["Phase 5: Payments & Webhooks<br/>(Razorpay Test Mode, Webhook Idempotency, Asynq)"]
    P6["Phase 6: Hardening & VPS Deployment<br/>(Playwright E2E, Backups/Restore, Caddy, Terraform)"]

    P0 --> P1
    P1 --> P2
    P2 --> P3
    P3 --> P4
    P4 --> P5
    P5 --> P6
```

---

## 2. Phase Breakdown & Acceptance Criteria

### Phase 0: Specification & Architecture (CURRENT MILESTONE)
*Objective*: Inspect workspace, establish product requirements, design database schema, formulate threat model, design import process, and create architectural documentation.
- [x] Workspace inspection (verified clean/empty state).
- [x] Create `docs/PRODUCT_SPEC.md` (Product vision, user personas, learning loop, non-goals).
- [x] Create `docs/ARCHITECTURE.md` (Modular monolith, package layout, request flows, cross-cutting concerns).
- [x] Create `docs/DATABASE_DESIGN.md` (PostgreSQL physical schema, UUIDv7, invariants, locking).
- [x] Create `docs/SECURITY.md` (STRIDE threat model, Argon2id, session cookies, payment & AI safeguards).
- [x] Create `docs/TESTING.md` (Testing pyramid, unit/integration/E2E test suites, CI gates).
- [x] Create `docs/DEPLOYMENT.md` (Docker Compose, VPS layout, automated backup/restore, Caddy).
- [x] Create `docs/AI_AND_CREDIT_MODEL.md` (Gemini abstraction, rate limits, double-entry credit ledger).
- [x] Create `docs/QUESTION_BANK_IMPORT.md` (Excel import process, duplicate detection, CLI dry-run strategy).
- [x] Create `docs/decisions/` ADRs 0001 through 0006.
- [x] **Milestone Gate**: Stop and wait for user review and approval before writing any application code.

---

### Phase 1: Engineering Foundation
*Objective*: Establish a production-grade Go project skeleton, configuration management, database connectivity, migrations, code generation, and CI automation.
- **Tasks**:
  1. Initialize Go module (`go mod init`).
  2. Implement `internal/config`: Type-safe environment variable parsing with validation using `caarlos0/env/v11` or standard library.
  3. Implement `internal/platform/logger`: Structured JSON logging via Go's standard `log/slog` with request ID propagation.
  4. Configure PostgreSQL connection pooling using `pgxpool` with health checks, connection limits, and graceful shutdown.
  5. Setup `goose` migration runner (`cmd/migrate/main.go`) and create the initial migration file `migrations/00001_initial_schema.sql`.
  6. Configure `sqlc.yaml` and verify type-safe Go code generation from SQL queries.
  7. Implement HTTP server with router (`chi/v5` or standard library `net/http` 1.22+ mux), graceful shutdown, `/healthz`, and `/readyz` endpoints.
  8. Create `docker-compose.yml` for local PostgreSQL 16 and Redis 7.
  9. Establish GitHub Actions workflow (`.github/workflows/ci.yml`) for `golangci-lint` and `go test`.
- **Learning Highlights**:
  - Tuning `pgxpool` connection pools (MaxConns, MinConns, MaxConnLifetime) to prevent connection leaks.
  - Compile-time type safety with `sqlc` versus runtime ORM errors.
  - Signal handling (`os.Interrupt`, `syscall.SIGTERM`) and graceful HTTP shutdown.
- **Milestone Acceptance Criteria**:
  - `docker compose up -d` starts PostgreSQL and Redis with clean health checks.
  - `go run cmd/migrate/main.go up` runs migration without error.
  - `sqlc generate` runs cleanly.
  - `curl -i http://localhost:8080/readyz` returns HTTP 200 with DB ping confirmation.
  - CI workflow runs and passes in GitHub Actions.

---

### Phase 2: Identity & Security
*Objective*: Implement robust authentication, server-side session management, role-based authorization, and administrative audit logging.
- **Tasks**:
  1. Implement password hashing service using Argon2id with recommended parameters (64MB memory, 3 iterations, 2 parallelism).
  2. Implement user registration (`POST /api/v1/auth/register`) and login (`POST /api/v1/auth/login`).
  3. Implement session service: Generates 32-byte cryptographically random tokens, stores SHA-256 hashes in PostgreSQL `sessions` table, sets `HttpOnly`, `SameSite=Lax` cookies.
  4. Implement session rotation on login and privilege change; implement single session logout and "logout all devices".
  5. Build authentication and authorization middleware (`RequireAuth`, `RequireRole`).
  6. Implement resource ownership checks in repository layer.
  7. Implement CLI tool for secure admin account provisioning (`go run cmd/server/main.go admin create`).
  8. Implement `audit_logs` repository for recording sensitive security events.
- **Learning Highlights**:
  - Why Argon2id is superior to bcrypt for modern high-memory GPU defense.
  - Mitigating session hijacking and session fixation attacks.
  - Implementing cookie security headers (`HttpOnly`, `SameSite`, `Secure`).
- **Milestone Acceptance Criteria**:
  - Unit tests verify Argon2id hashing and verification logic.
  - Integration tests verify registration, session cookie issuance, authenticated endpoint access, and session revocation on logout.
  - Unauthenticated access returns HTTP 401 with RFC 9457 Problem Details.
  - Candidate accessing another candidate's resource returns HTTP 404 (zero information leakage).
  - Race condition tests confirm session tokens cannot be fixation-exploited.

---

### Phase 3: Core Preparation Engine & Question Bank Importer
*Objective*: Implement the curated question catalog, hierarchical patterns, master and personalized roadmaps, canonical user progress, attempt logging, spaced repetition engine, and the question bank importer CLI.
- **Tasks**:
  1. Implement catalog domain and queries (`questions`, `patterns`, `question_patterns`, `companies`, `question_company_evidence`).
  2. Implement roadmap domain: Master template roadmaps and user-customized roadmaps.
  3. Implement canonical progress tracking: `user_question_progress` (exactly one row per user-question pair).
  4. Implement attempt tracking: `question_attempts` logging outcome, solving time, difficulty, mistake taxonomy, and personal notes.
  5. Implement SM-2 / spaced repetition revision engine: Dynamic interval computation, retention probability estimation, and anti-backlog overdue triage.
  6. Build `cmd/import-questions`: Excel parsing (`excelize`), duplicate detection, schema mapping, `--dry-run` validation report, and `--commit` transaction execution.
- **Learning Highlights**:
  - Enforcing PostgreSQL constraints (`UNIQUE(user_id, question_id)`) to maintain global canonical progress across multiple roadmaps.
  - Atomic multi-table database transactions (`question_attempts` + `user_question_progress` + `revision_schedules`).
  - Adapting cognitive spaced repetition algorithms (SM-2/FSRS) to algorithmic problem solving.
- **Milestone Acceptance Criteria**:
  - Unit tests verify SM-2 interval calculations under various outcomes (`SOLVED_INDEPENDENTLY` vs `SOLVED_AFTER_EDITORIAL`).
  - Integration tests verify that solving a question in Roadmap A automatically updates its progress in Roadmap B.
  - Importer CLI passes `--dry-run` validation on test spreadsheets and successfully commits canonical questions without creating duplicate rows.
  - Re-running the importer updates metadata without corrupting user progress or attempt history.

---

### Phase 4: User Experience, Daily Dashboard & AI Credits
*Objective*: Build the responsive Next.js frontend, daily preparation dashboard, attempt logging modal, revision queue, Gemini AI tutor integration, and double-entry credit ledger.
- **Tasks**:
  1. Initialize Next.js 14+ (App Router) project with TypeScript, Tailwind CSS, and shadcn/ui components.
  2. Implement authentication flow in frontend (Login, Register, Session context, Protected routes).
  3. Build Daily Dashboard: Today's focus, due revisions, weak pattern indicators, streak metrics.
  4. Build Question Catalog view with pattern filtering, search, and difficulty tags.
  5. Build Attempt Logging Modal: Outcome selection, timer, mistake taxonomy checkboxes, notes.
  6. Implement AI Provider abstraction and Google Gemini client (`internal/ai`).
  7. Implement Progressive Hint Ladder component (Level 1 Nudge to Level 4 Pseudocode).
  8. Implement double-entry credit ledger (`credit_ledger_entries`, `credit_accounts`) with row-level locking (`SELECT ... FOR UPDATE`).
  9. Implement Admin Panel: User lookup, catalog management, manual promotional credit grants with audit logs.
- **Learning Highlights**:
  - Avoiding frontend state duplication: Backend remains the single source of truth for business rules.
  - Safe prompt engineering and injection defense using XML delimiter isolation.
  - Implementing double-entry accounting in PostgreSQL to ensure financial consistency under concurrency.
- **Milestone Acceptance Criteria**:
  - User can register, log in, view their daily study plan, and log a question attempt via the browser UI.
  - Requesting an AI hint checks balance, displays estimated credit cost, reserves credits, calls Gemini, and deducts credits atomically.
  - Simulated Gemini timeout or failure leaves user credit balance untouched (0 charge).
  - Admin can grant promotional credits with a documented reason, producing an immutable ledger record and audit log.

---

### Phase 5: Payments & Background Worker
*Objective*: Implement Razorpay test-mode payment gateway integration, checkout flow, HMAC signature verification, idempotent webhook handling, and atomic credit delivery.
- **Tasks**:
  1. Implement server-side Razorpay order creation (`POST /api/v1/payments/orders`).
  2. Implement Razorpay test-mode checkout integration in the Next.js frontend.
  3. Implement webhook handler (`POST /api/v1/payments/webhook`) with HMAC-SHA256 signature verification.
  4. Implement webhook idempotency using `payment_webhook_events` table to prevent duplicate crediting.
  5. Execute payment fulfillment in an atomic PostgreSQL transaction: Mark order `PAID`, record transaction, insert credit ledger entry, and update cached balance.
  6. Setup Redis-backed background worker (`asynq` or simple worker pool) for asynchronous email notifications and nightly reconciliation tasks.
  7. Implement nightly ledger reconciliation check (`SUM(ledger) == cached_balance`).
- **Learning Highlights**:
  - Why client-side payment callbacks must never be trusted.
  - Idempotent webhook processing in high-concurrency environments.
  - Designing financial reconciliation audits in backend software.
- **Milestone Acceptance Criteria**:
  - Valid Razorpay webhook results in order marked `PAID` and exact credit amount added to ledger.
  - Invalid signature returns HTTP 400 with zero database changes.
  - Sending the identical webhook payload 3 times results in HTTP 200 responses with exactly **one** credit grant entry in `credit_ledger_entries`.
  - Concurrent webhook requests do not produce race conditions.

---

### Phase 6: Hardening, Observability & VPS Deployment
*Objective*: Execute end-to-end integration testing, security audit, database backup/restore verification, Terraform provisioning, and live deployment on a modest VPS.
- **Tasks**:
  1. Implement automated Playwright end-to-end test suite for critical candidate workflows.
  2. Execute security hardening: CORS audit, Content Security Policy (CSP), rate limit tuning, dependency vulnerability scan (`govulncheck`, `npm audit`).
  3. Implement automated database backup script (`pg_dump` $\rightarrow$ `zstd` $\rightarrow$ `age` encryption $\rightarrow$ offsite S3 upload).
  4. Write and verify automated disaster recovery restore script on a clean container.
  5. Create Terraform module for provisioning a low-cost VPS (Hetzner / DigitalOcean), DNS records, and cloud firewall.
  6. Configure Caddy reverse proxy with automatic Let's Encrypt TLS.
  7. Deploy application stack via Docker Compose with systemd auto-restart.
  8. Perform smoke testing against live VPS deployment in test mode.
- **Learning Highlights**:
  - End-to-end testing of full-stack web applications.
  - Zero-cost automated database encryption and offsite cold storage.
  - Production infrastructure automation with Terraform and Caddy.
- **Milestone Acceptance Criteria**:
  - Full Playwright E2E suite passes in CI.
  - Automated restore test successfully reconstructs database from encrypted backup and asserts table counts.
  - Application runs on VPS under HTTPS with valid TLS certificate.
  - Health check endpoints (`/healthz`, `/readyz`) respond in < 10ms.
  - All test credentials remain safely isolated; zero live payment credentials enabled.
